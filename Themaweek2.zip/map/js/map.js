console.log('Ahmad')

let NoorWegen = document.querySelector('.Noorwegen')
NoorWegen.addEventListener('click',function() {
    document.querySelector(".info").innerHTML = "<p class= nor-text>Noorwegen, officieel het Koninkrijk Noorwegen, is een land in Noord-Europa. Noorwegen ligt op het westelijk deel van het Scandinavisch Schiereiland en grenst aan Zweden, Finland en Rusland <a href='addinfo.php'class = btn btn btn-dark> add info</a></p>";});


    let FinLand = document.querySelector('.FinLand')
    FinLand.addEventListener('click',function() {
        document.querySelector(".info").innerHTML = "<p class= nor-text>Finland, officieel de Republiek Finland, is een staat in Noord-Europa met 5.571.665 inwoners. Finland grenst in het oosten aan Rusland, in het noorden aan Noorwegen en in het noordwesten aan Zweden. Ten zuiden wordt het van Estland gescheiden door de Finse Golf <a href='addinfo.php' class = btn btn btn-dark> add info</a>.</p>";});

let Zweden = document.querySelector('.Zweden')
    Zweden.addEventListener('click',function() {
         document.querySelector(".info").innerHTML = "<p class= nor-text>Zweden, officieel het Koninkrijk Zweden, is een Scandinavisch land in Noord-Europa. Zweden grenst aan Noorwegen in het westen en noorden, aan Finland in het noorden en oosten, aan de Botnische Golf en Oostzee in het noorden, midden en zuidoosten en verder aan het Skagerrak en het Kattegat in het zuidwesten <a href='addinfo.php' class = btn btn btn-dark> add info</a>  </p>";});

let Engeland = document.querySelector('.Engeland')
Engeland.addEventListener('click',function() {
    document.querySelector(".info").innerHTML = "<p class= nor-text>Engeland is een voormalig koninkrijk en maakt als constituerend land met Noord-Ierland, Schotland en Wales deel uit van één soevereine staat: het Verenigd Koninkrijk. Van deze vier is Engeland het gebied met de meeste inwoners en de grootste oppervlakte. <a href='addinfo.php' class = btn btn btn-dark> add info</a></p>";});

let Estonia= document.querySelector('.Estonia')
   Estonia.addEventListener('click',function() {
        document.querySelector(".info").innerHTML = "<p class= nor-text>Estland, officieel de Republiek Estland, is een land in Noordoost-Europa, dat in het westen wordt begrensd door de Oostzee, in het noorden door de Finse Golf, in het oosten door Rusland en in het zuiden door Letland <a href='addinfo.php' class = btn btn btn-dark> add info</a></p>";});


 let Denmark = document.querySelector('.Denmark')
 Denmark.addEventListener('click',function() {
         document.querySelector(".info").innerHTML = "<p class= nor-text>Denemarken, officieel het Koninkrijk Denemarken, is een land in Scandinavië, in het noorden van Europa. Denemarken vormt samen met Groenland en de Faeröer het Koninkrijk Denemarken <a href='addinfo.php' class = btn btn btn-dark> add info</a></p>";});



 let Lativia = document.querySelector('.Lativia')
    Lativia.addEventListener('click',function() {
    document.querySelector(".info").innerHTML = "<p class= nor-text>Letland, officieel de Republiek Letland, is een land in Noordoost-Europa en een van de Baltische landen aan de Oostzee <a href='addinfo.php' class = btn btn btn-dark> add info</a></p>";});
    
    
 let BELAR = document.querySelector('.BELAR')
  BELAR.addEventListener('click',function() {
    document.querySelector(".info").innerHTML = "<p class= nor-text>Wit-Rusland of Belarus, officieel de Republiek Belarus, is een binnenstaat in Oost-Europa. Het land grenst aan Rusland in het noordoosten, aan Oekraïne in het zuiden, aan Polen in het westen en aan Litouwen en Letland in het noordwesten. De hoofdstad is Minsk. <a href='addinfo.php' class = btn btn btn-dark> add info</a></p>";});

let NORTHERNIRELAND  = document.querySelector('.NORTHERN-IRELAND')
    NORTHERNIRELAND.addEventListener('click',function() {
    document.querySelector(".info").innerHTML = "<p class= nor-text>Noord-Ierland maakt als constituerend land met Engeland, Schotland en Wales deel uit van één staat: het Verenigd Koninkrijk. Het is van deze vier gebieden het enige dat niet op het eiland Groot-Brittannië, maar op het eiland Ierland ligt en daarvan het noordoostelijk deel uitmaakt <a href='addinfo.php' class = btn btn btn-dark> add info</a>.</p>";});


let GERMANY  = document.querySelector('.GERMANY')
GERMANY.addEventListener('click',function() {
    document.querySelector(".info").innerHTML = "<p class= nor-text>De Bondsrepubliek Duitsland, kortweg Duitsland, is een land in West- en of Centraal-Europa. Het heeft een grondgebied van 357.022 km² en grenst in het noorden aan de Oostzee, de Noordzee en Denemarken <a href='addinfo.php' class = btn btn btn-dark> add info</a> </p>";});


let POLAND = document.querySelector('.POLAND')
POLAND.addEventListener('click',function() {
    document.querySelector(".info").innerHTML = "<p class= nor-text>Polen, officieel de Republiek Polen, is een land in Centraal-Europa. In het westen wordt het begrensd door Duitsland, in het zuiden door Tsjechië en Slowakije, in het oosten door Litouwen, Wit-Rusland en Oekraïne en in het noorden door de Oostzee en de Russische exclave Kaliningrad <a href='addinfo.php' class = btn btn btn-dark> add info</a></p>";});


let IRELAND = document.querySelector('.IRELAND')
 IRELAND.addEventListener('click',function() {
    document.querySelector(".info").innerHTML = "<p class= nor-text>Ierland is het op twee na grootste eiland van Europa, en wordt voornamelijk omringd door de Atlantische Oceaan, behalve aan de oostzijde van het eiland, waar de Ierse Zee ligt. Het eiland ligt ten westen van het eiland Groot-Brittannië <a href='addinfo.php' class = btn btn btn-dark> add info</a></p>";});

let NETHERLANDS  = document.querySelector('.NETHERLANDS')
NETHERLANDS.addEventListener('click',function() {
    document.querySelector(".info").innerHTML = "<p class= nor-text>Nederland is een van de landen binnen het Koninkrijk der Nederlanden. Nederland ligt voor het overgrote deel in het noordwesten van Europa, aan de Noordzee. Naast het Europese deel zijn er drie bijzondere gemeenten in de Caribische Zee, die ook wel Caribisch Nederland worden genoemd <a href='addinfo.php' class = btn btn btn-dark> add info</a></p>";});

let OEKRAÏNE = document.querySelector('.OEKRAÏNE')
OEKRAÏNE.addEventListener('click',function() {
    document.querySelector(".info").innerHTML = "<p class= nor-text>Oekraïne is een land in Oost-Europa met 44,32 miljoen inwoners met als hoofdstad Kiev. Het land grenst in het noordoosten en oosten aan Rusland, in het noordwesten aan Wit-Rusland, in het westen aan Polen, Slowakije en Hongarije en in het zuidwesten aan Roemenië en Moldavië. <a href='addinfo.php' class = btn btn btn-dark> add info</a> </p>";});


let BELGIË = document.querySelector('.BELGIË')
 BELGIË.addEventListener('click',function() {
    document.querySelector(".info").innerHTML = "<p class= nor-text>België, officieel het Koninkrijk België, is een West-Europees land dat aan de Noordzee ligt en aan Nederland, Duitsland, Luxemburg en Frankrijk grenst. Het land is 30.528 km² groot en heeft een bevolking van meer dan 11,6 miljoen inwoners <a href='addinfo.php' class = btn btn btn-dark> add info</a></p>";});

let FRANCE = document.querySelector('.FRANCE')
FRANCE.addEventListener('click',function() {
    document.querySelector(".info").innerHTML = "<p class= nor-text>Frankrijk, officieel de Franse Republiek, is een land in West-Europa en qua oppervlakte het op twee na grootste Europese land. Frankrijk ligt tussen het Kanaal, de Atlantische Oceaan en de Golf van Biskaje, België en Luxemburg, Duitsland, Zwitserland en Italië en Spanje, Andorra, de Middellandse Zee en Monaco <a href='addinfo.php' class = btn btn btn-dark> add info</a>.</p>";});

let TSJECHIE = document.querySelector('.TSJECHIE')
TSJECHIE.addEventListener('click',function() {
    document.querySelector(".info").innerHTML = "<p class= nor-text>Tsjechië, officieel de Tsjechische Republiek, is een land in Centraal-Europa. Het land grenst in het westen en noordwesten aan Duitsland, in het noorden aan Polen, in het oosten aan Slowakije en in het zuiden aan Oostenrijk <a href='addinfo.php' class = btn btn btn-dark> add info</a>.</p>";});


let LUXEMBURG = document.querySelector('.LUXEMBURG')
LUXEMBURG.addEventListener('click',function() {
    document.querySelector(".info").innerHTML = "<p class= nor-text>Luxemburg, officieel het Groothertogdom Luxemburg, is een land in het westen van Europa dat grenst aan België, Duitsland en Frankrijk. Met een oppervlakte van 2.586 km² en met iets meer dan een half miljoen inwoners is het groothertogdom op Malta na het kleinste land binnen de Europese Unie <a href='addinfo.php' class = btn btn btn-dark> add info</a></p>";});


let SLOWAKIJE = document.querySelector('.SLOWAKIJE')
SLOWAKIJE.addEventListener('click',function() {
    document.querySelector(".info").innerHTML = "<p class= nor-text>Slowakije of Slovakije is een land in Centraal-Europa. De officiële benaming is Slowaakse Republiek of Slovaakse Republiek. De hoofdstad en grootste stad van het land is Bratislava. In totaal telt Slowakije meer dan vijf miljoen inwoners. <a href='addinfo.php' class = btn btn btn-dark> add info</a></p>";});


let OOSTENRIJK  = document.querySelector('.OOSTENRIJK')
   OOSTENRIJK.addEventListener('click',function() {
    document.querySelector(".info").innerHTML = "<p class= nor-text>Oostenrijk, officieel de Republiek Oostenrijk, is een binnenstaat in Centraal-Europa. Het land grenst in het westen aan Zwitserland en Liechtenstein, in het noorden aan Duitsland en Tsjechië, in het oosten aan Slowakije en Hongarije en in het zuiden aan Italië en Slovenië. <a href='addinfo.php' class = btn btn btn-dark> add info</a></p>";});

let HONGARIJE = document.querySelector('.HONGARIJE')
  HONGARIJE.addEventListener('click',function() {
    document.querySelector(".info").innerHTML = "<p class= nor-text>Hongarije is een land in Centraal-Europa, van noord naar zuid doorsneden door de Donau en grenzend aan Oostenrijk, Slowakije, Oekraïne, Roemenië, Servië, Kroatië en Slovenië. Hongarije is lid van de Verenigde Naties, de Europese Unie, de NAVO en de Visegrádgroep <a href='addinfo.php' class = btn btn btn-dark> add info</a></p>";});


let MOLDAVIE = document.querySelector('.MOLDAVIE')
 MOLDAVIE.addEventListener('click',function() {
    document.querySelector(".info").innerHTML = "<p class= nor-text>De Republiek Moldavië is een republiek in Oost-Europa, grotendeels gelegen tussen de rivieren Proet en Dnjestr. Het land wordt in het westen begrensd door Roemenië en in het noorden, oosten en zuiden door Oekraïne. De hoofdstad is Chisinau. Moldavië behoorde tot 1991 tot de Sovjet-Unie <a href='addinfo.php' class = btn btn btn-dark> add info</a></p>";});

let ROEMENIE  = document.querySelector('.ROEMENIE')
 ROEMENIE.addEventListener('click',function() {
    document.querySelector(".info").innerHTML = "<p class= nor-text>Roemenië is een republiek in Zuidoost-Europa grenzend aan de Zwarte Zee, Bulgarije, Servië, Oekraïne, Hongarije en Moldavië. Op die laatste twee na is het Romaanse Roemenië omringd door Slavische landen. Het land kent veel culturen, talen en religies die onderling beïnvloed zijn <a href='addinfo.php' class = btn btn btn-dark> add info</a></p>";});

let ZWITSERLAND= document.querySelector('.ZWITSERLAND')
     ZWITSERLAND.addEventListener('click',function() {
    document.querySelector(".info").innerHTML = "<p class= nor-text>Zwitserland, officieel de Zwitserse Bondsstaat is een land in het westen van Europa met als buren Duitsland in het noorden, Frankrijk in het westen, Italië in het zuiden, Oostenrijk en Liechtenstein in het oosten <a href='addinfo.php' class = btn btn btn-dark> add info</a></p>";});


let ITALY = document.querySelector('.ITALY')
    ITALY.addEventListener('click',function() {
    document.querySelector(".info").innerHTML = "<p class= nor-text>Italië, officieel de Republiek Italië, is een land in Zuid-Europa. Het noorden van Italië grenst aan Frankrijk, Zwitserland, Oostenrijk en Slovenië. De rest van het land wordt omringd door de Tyrreense, de Middellandse, de Ionische en Adriatische Zee <a href='addinfo.php' class = btn btn btn-dark> add info</a></p>";});

let SLOVENIE = document.querySelector('.SLOVENIE')
    SLOVENIE.addEventListener('click',function() {
    document.querySelector(".info").innerHTML = "<p class= nor-text>Slovenië, officieel de Republiek Slovenië, is een land in Midden-Europa aan de zuidrand van de Alpen, en is lid van de Europese Unie. Het wordt begrensd door Oostenrijk in het noorden, Italië en de Adriatische Zee in het westen, Kroatië in het zuiden en oosten en Hongarije in het noordoosten. <a href='addinfo.php' class = btn btn btn-dark> add info</a></p>";});
    
    
let KROATIE= document.querySelector('.KROATIE')
  KROATIE.addEventListener('click',function() {
    document.querySelector(".info").innerHTML = "<p class= nor-text>Kroatië, officieel Republiek Kroatië, is een land in Zuidoost-Europa. Het grenst aan Slovenië en Hongarije in het noorden, Bosnië en Montenegro in het zuiden en Servië in het oosten. In het westen ligt de Adriatische Zee, waar de Kroatische territoriale wateren grenzen aan die van Italië <a href='addinfo.php' class = btn btn btn-dark> add info</a></p>";});

let BOSNIE = document.querySelector('.BOSNIE')
    BOSNIE.addEventListener('click',function() {
    document.querySelector(".info").innerHTML = "<p class= nor-text>Bosnië en Herzegovina is een federatieve republiek in het zuidoosten van Europa, gelegen in het westen van de Balkan. Het land is bij het Verdrag van Dayton opgedeeld in twee entiteiten: de Federatie van Bosnië en Herzegovina en de deelrepubliek Servische Republiek <a href='addinfo.php' class = btn btn btn-dark> add info</a></p>";});


let BULGARIJE = document.querySelector('.BULGARIJE')
    BULGARIJE.addEventListener('click',function() {
    document.querySelector(".info").innerHTML = "<p class= nor-text>De Republiek Bulgarije is een land in Zuidoost-Europa, gelegen in het oosten van het Balkanschiereiland en ten zuiden van de rivier de Donau. Bulgarije grenst in het noorden aan Roemenië, in het westen aan Servië en Noord-Macedonië en in het zuiden aan Griekenland en Turkije <a href='addinfo.php' class = btn btn btn-dark> add info</a></p>";});

let SPAIN = document.querySelector('.SPAIN')
    SPAIN.addEventListener('click',function() {
    document.querySelector(".info").innerHTML = "<p class= nor-text>Spanje, officieel het Koninkrijk Spanje, is een land in het zuidwesten van Europa met 50.015.792 inwoners en een oppervlakte van 505.992 km². Het land beslaat grofweg 80% van het Iberisch Schiereiland <a href='addinfo.php' class = btn btn btn-dark> add info</a></p>";});

let CORSE= document.querySelector('.CORSE')
    CORSE.addEventListener('click',function() {
    document.querySelector(".info").innerHTML = "<p class= nor-text>Corsica is een eiland in de Middellandse Zee. Het was tot 13 mei 1991 een van de regio's van Frankrijk. Vanaf 14 mei 1991 vormt het eiland de Collectivité territoriale de Corse en heeft het een speciale status binnen de Franse Republiek, waardoor het meer autonomie heeft dan de regio's op het vasteland <a href='addinfo.php' class = btn btn btn-dark> add info</a></p>";});

let ALBANIE = document.querySelector('.ALBANIE')
    ALBANIE.addEventListener('click',function() {
    document.querySelector(".info").innerHTML = "<p class= nor-text>Albanië, officieel de Republiek Albanië, is een land in Zuidoost-Europa. Het land ligt in het zuidwesten van de Balkan aan de Ionische en Adriatische Zee. Albanië grenst kloksgewijs aan Montenegro, Kosovo, Noord-Macedonië en Griekenland. De hoofdstad van Albanië is Tirana <a href='addinfo.php' class = btn btn btn-dark> add info</a></p> ";});
    
    
let TURKIJE = document.querySelector('.TURKIJE')
    TURKIJE.addEventListener('click',function() {
    document.querySelector(".info").innerHTML = "<p class= nor-text>Turkije, officieel de Republiek Turkije, is een transcontinentaal land dat voornamelijk in Anatolië in Zuidwest-Azië ligt, met een deel op het Balkanschiereiland in Zuidoost-Europa. Ankara is de hoofdstad en regeringszetel van Turkije, terwijl Istanboel de grootste stad en het financiële centrum van het land is <a href='addinfo.php' class = btn btn btn-dark> add info</a></p>";});

let PORTOGAL = document.querySelector('.PORTOGAL')
    PORTOGAL .addEventListener('click',function() {
    document.querySelector(".info").innerHTML = "<p class= nor-text>Portugal, officieel de Portugese Republiek, is een land in het uiterste zuidwesten van Europa. Het vormt het westelijk deel van het Iberisch Schiereiland. In het oosten en noorden grenst het aan Spanje, het enige buurland, en in het zuiden en westen aan de Atlantische Oceaan. V</p>";});


let GRIEKENLAND = document.querySelector('.GRIEKENLAND')
    GRIEKENLAND.addEventListener('click',function() {
    document.querySelector(".info").innerHTML = "<p class= nor-text>Griekenland, officieel de Helleense Republiek, is een land in Zuidoost-Europa, bestaande uit het zuidelijkste deel van het Balkanschiereiland en een groot aantal eilanden. Griekenland heeft een bevolking van ruim 10 miljoen inwoners. De hoofdstad en grootste stad is Athene <a href='addinfo.php' class = btn btn btn-dark> add info</a></p>";});

let SARDINIE= document.querySelector('.SARDINIE')
    SARDINIE.addEventListener('click',function() {
    document.querySelector(".info").innerHTML = "<p class= nor-text> Sardinië is een Italiaans eiland in de Middellandse Zee</p>";});


let KRETA = document.querySelector('.KRETA')
    KRETA.addEventListener('click',function() {
    document.querySelector(".info").innerHTML = "<p class= nor-text>Kreta is het grootste van de Griekse eilanden, en is in grootte het vijfde eiland in de Middellandse Zee. Het eiland vormt, samen met een paar kleine nabijgelegen eilanden, tevens de zuidelijkste van de dertien Griekse regio's.</p>";});


let MALTA= document.querySelector('.MALTA')
 MALTA.addEventListener('click',function() {
    document.querySelector(".info").innerHTML = "<p class= nor-text>Malta, officieel de Republiek Malta, is een Zuid-Europese dwergstaat gelegen in de Middellandse Zee die bestaat uit de eilanden Malta, Gozo, Comino, het kleinere Manoel Island en de onbewoonde eilanden Cominotto, Filfla, Fungus Rock en de Saint Paul's Islands. </p>";});

let CYPRUS = document.querySelector('.CYPRUS')
CYPRUS.addEventListener('click',function() {
    document.querySelector(".info").innerHTML = "<p class= nor-text>De Republiek Cyprus is gelegen op het gelijknamige eiland Cyprus in het oosten van de Middellandse Zee, ca. 70 km ten zuiden van Turkije en 105 km ten westen van Syrië. Cyprus behoort geografisch gezien tot Azië, maar om politieke en culturele redenen wordt het ook tot Europa gerekend</p>";});






